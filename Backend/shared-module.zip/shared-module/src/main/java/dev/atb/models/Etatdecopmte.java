package dev.atb.models;

public enum Etatdecopmte {
    ETAT
}
